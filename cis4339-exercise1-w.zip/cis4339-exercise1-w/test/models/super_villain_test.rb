require 'test_helper'

class SuperVillainTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
