require 'test_helper'

class MinionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
