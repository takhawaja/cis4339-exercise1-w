class SuperVillain < ApplicationRecord
end
