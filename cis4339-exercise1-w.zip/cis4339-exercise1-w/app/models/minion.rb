class Minion < ApplicationRecord
  belongs_to :super_villain
end
