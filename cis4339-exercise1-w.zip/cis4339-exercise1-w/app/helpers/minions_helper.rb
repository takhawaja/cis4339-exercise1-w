module MinionsHelper
end
