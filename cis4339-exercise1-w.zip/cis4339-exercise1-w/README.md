# README

This is the class exercise for CIS 4339, Fall 2019 Sept. 11 class.
